// import { RangeSlider } from "@chakra-ui/react";


export const jacketProduct = [ 
    {
        id: 1,
        pic:  'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTC1uenMtPG8MRPVPyCM35bsHDGSyYvI0EX9A&usqp=CAU',
        heading : "WRONG",
        discreption: "Men Solid Biker Jacket",
        price: "Rs.2249"
    },
    {
        id: 1,
        pic:  'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTC1uenMtPG8MRPVPyCM35bsHDGSyYvI0EX9A&usqp=CAU',
        heading : "WRONG",
        discreption: "Men Solid Biker Jacket",
        price: "Rs.2249"
    },
    //{
    //     id: 1,
    //     pic:  <img src="https://assets.myntassets.com/f_webp,dpr_1.5,q_60,w_210,c_limit,fl_progressive/assets/images/6832181/2019/11/19/07df80b4-be08-46a6-b910-63fe5d3ccbbe1574153174233-WROGN-Men-Brown-Solid-Biker-Jacket-4291574153171876-1.jpg" alt=""/>,
    //     heading : "WRONG",
    //     discreption: "Men Solid Biker Jacket",
    //     price: "Rs.2249"
    // }
    // ,{
    //     id: 1,
    //     pic:  <img src="https://assets.myntassets.com/f_webp,dpr_1.5,q_60,w_210,c_limit,fl_progressive/assets/images/6832181/2019/11/19/07df80b4-be08-46a6-b910-63fe5d3ccbbe1574153174233-WROGN-Men-Brown-Solid-Biker-Jacket-4291574153171876-1.jpg" alt=""/>,
    //     heading : "WRONG",
    //     discreption: "Men Solid Biker Jacket",
    //     price: "Rs.2249"
    // },{
    //     id: 1,
    //     pic:  <img src="https://assets.myntassets.com/f_webp,dpr_1.5,q_60,w_210,c_limit,fl_progressive/assets/images/6832181/2019/11/19/07df80b4-be08-46a6-b910-63fe5d3ccbbe1574153174233-WROGN-Men-Brown-Solid-Biker-Jacket-4291574153171876-1.jpg" alt=""/>,
    //     heading : "WRONG",
    //     discreption: "Men Solid Biker Jacket",
    //     price: "Rs.2249"
    // },{
    //     id: 1,
    //     pic:  <img src="https://assets.myntassets.com/f_webp,dpr_1.5,q_60,w_210,c_limit,fl_progressive/assets/images/6832181/2019/11/19/07df80b4-be08-46a6-b910-63fe5d3ccbbe1574153174233-WROGN-Men-Brown-Solid-Biker-Jacket-4291574153171876-1.jpg" alt=""/>,
    //     heading : "WRONG",
    //     discreption: "Men Solid Biker Jacket",
    //     price: "Rs.2249"
    // },
    // {
    //     id: 1,
    //     pic:  <img src="https://assets.myntassets.com/f_webp,dpr_1.5,q_60,w_210,c_limit,fl_progressive/assets/images/6832181/2019/11/19/07df80b4-be08-46a6-b910-63fe5d3ccbbe1574153174233-WROGN-Men-Brown-Solid-Biker-Jacket-4291574153171876-1.jpg" alt=""/>,
    //     heading : "WRONG",
    //     discreption: "Men Solid Biker Jacket",
    //     price: "Rs.2249"
    // },
    // {
    //     id: 1,
    //     pic:  <img src="https://assets.myntassets.com/f_webp,dpr_1.5,q_60,w_210,c_limit,fl_progressive/assets/images/6832181/2019/11/19/07df80b4-be08-46a6-b910-63fe5d3ccbbe1574153174233-WROGN-Men-Brown-Solid-Biker-Jacket-4291574153171876-1.jpg" alt=""/>,
    //     heading : "WRONG",
    //     discreption: "Men Solid Biker Jacket",
    //     price: "Rs.2249"
    // }
]