import React from 'react';

function Done() {
    // console.log("hdfbjhdvjhdvjhvjhvjhdjhdvjhvjhdvjhvjh")
    return <div style={{
        margin: '10%'
    }}>
     <h1>Order Confirm...!</h1>
  </div>;
}

export default Done;
